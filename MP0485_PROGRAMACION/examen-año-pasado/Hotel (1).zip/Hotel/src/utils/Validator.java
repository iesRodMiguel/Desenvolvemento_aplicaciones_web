package utils;

public class Validator {
    public boolean isValid(Object data) {
        throw new UnsupportedOperationException();
    }
    
    public String message() {
        return "";
    }
}
