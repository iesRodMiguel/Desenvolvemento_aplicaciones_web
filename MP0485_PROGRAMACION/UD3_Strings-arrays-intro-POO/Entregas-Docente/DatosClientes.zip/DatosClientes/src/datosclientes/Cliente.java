/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package datosclientes;

/**
 *
 * @author miguel
 */
public class Cliente {
    
    private String nome;
    private String apelidos;
    private String nif;
    private String telefono;
    private String email;
    
    public Cliente (String nome, String apelidos, String nif){
        this.nome = nome;
        this.apelidos = apelidos;
        this.nif = nif;
    }
    
    //Getters
    
    public String getNome(){
        return nome;
    }
    public String getApelidos(){
        return apelidos;
    }
    public String getNif(){
        return nif;
    }
    public String getTelefono(){
        return telefono;
    }
    public String getEmail(){
        return email;
    }
    
    // Setters
    
    public void setTelefono(){
    
        this.telefono = telefono;
    }
    public void setEmail(){
    
        this.email = email;
    }
    
    //Método para imprimir de acuerdo al patrón especificado en el enunciado
    
    public void showClient(){
    
        System.out.printf("[%s], %s, %s", nif, nome, apelidos);
    }
}
